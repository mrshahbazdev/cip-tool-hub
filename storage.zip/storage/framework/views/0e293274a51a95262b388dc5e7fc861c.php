<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaaS Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <nav class="bg-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-indigo-600">🚀 SaaS Platform</h1>
                    <div class="space-x-4">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                            <span class="text-gray-700">Hi, <?php echo e(auth()->user()->name); ?></span>
                            <a href="<?php echo e(route('dashboard')); ?>" class="text-indigo-600 hover:text-indigo-800">Dashboard</a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800">Logout</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-indigo-600">Login</a>
                            <a href="<?php echo e(route('register')); ?>" class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Sign Up</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Hero -->
        <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
            <div class="max-w-7xl mx-auto px-4 text-center">
                <h2 class="text-5xl font-bold mb-4">Choose Your Perfect Tool</h2>
                <p class="text-xl">Get your own subdomain in seconds! 🎉</p>
            </div>
        </div>

        <!-- Tools Grid -->
        <div class="max-w-7xl mx-auto px-4 py-12">
            <h3 class="text-3xl font-bold mb-8">Available Tools</h3>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tools->isEmpty()): ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                    <p class="text-yellow-700">⚠️ No tools available yet. Please run setup.</p>
                    <p class="text-sm text-yellow-600 mt-2">Run: php artisan tinker and create a tool</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition">
                            <div class="flex items-center mb-4">
                                <div class="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center">
                                    <span class="text-2xl font-bold text-indigo-600"><?php echo e(substr($tool->name, 0, 1)); ?></span>
                                </div>
                                <div class="ml-4">
                                    <h4 class="text-xl font-bold"><?php echo e($tool->name); ?></h4>
                                    <span class="text-sm text-gray-500 font-mono">.<?php echo e($tool->domain); ?></span>
                                </div>
                            </div>
                            
                            <p class="text-gray-600 mb-4"><?php echo e($tool->description); ?></p>
                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tool->packages->count() > 0): ?>
                                <p class="text-2xl font-bold text-indigo-600 mb-4">
                                    <?php echo e($tool->packages->first()->price == 0 ? 'FREE' : '€' . number_format($tool->packages->first()->price, 2)); ?>

                                </p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <a href="<?php echo e(route('tools.show', $tool)); ?>" 
                               class="block w-full text-center px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">
                                View Packages →
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\sites\cip-tools\resources\views/welcome.blade.php ENDPATH**/ ?>