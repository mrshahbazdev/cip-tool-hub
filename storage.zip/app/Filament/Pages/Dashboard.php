<?php

namespace App\Filament\Pages;

use Filament\Pages\Dashboard as BaseDashboard;  // ✅ Correct

class Dashboard extends BaseDashboard  // ✅ Correct
{
    //
}